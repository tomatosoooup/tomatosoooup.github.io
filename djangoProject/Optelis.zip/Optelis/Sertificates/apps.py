from django.apps import AppConfig


class SertificatesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Sertificates'
    verbose_name: str = 'Сертифікати'
