from django.apps import AppConfig


class RewievsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Rewievs'
    verbose_name: str = 'Відгуки'
